<?php 
$con = mysqli_connect("localhost","u5945_php","samandar001@","u5945_php");




?>